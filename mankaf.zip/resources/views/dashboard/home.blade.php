@extends('dashboard.layouts.master')
@section('content')
     welcome

@endsection
