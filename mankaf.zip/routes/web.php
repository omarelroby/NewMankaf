<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(
    [
        'prefix' => LaravelLocalization::setLocale(),
        'middleware' => [ 'localeSessionRedirect', 'localizationRedirect', 'localeViewPath' ]
    ], function(){ //...

Route::group( [
    'prefix' => 'dashboard',
    'namespace' => 'App\Http\Controllers\dashboard',
    'middleware' => 'auth:admin',
],function() {
    Route::get('/dashboard',[\App\Http\Controllers\api\HomeController::class,'index'])->name('dashboard');
    Route::resource('categories',\App\Http\Controllers\dashboard\CategoryController::class);
    Route::resource('country',\App\Http\Controllers\dashboard\CountryController::class);
    Route::resource('city',\App\Http\Controllers\dashboard\CityController::class);
    Route::resource('vehicle-type',\App\Http\Controllers\dashboard\VehicleController::class);
    Route::resource('models',\App\Http\Controllers\dashboard\ModelsController::class);
    Route::resource('years',\App\Http\Controllers\dashboard\YearsController::class);
    Route::resource('users',\App\Http\Controllers\dashboard\UsersController::class);
    Route::resource('drivers',\App\Http\Controllers\dashboard\DriversController::class);
    Route::resource('sliders',\App\Http\Controllers\dashboard\SlidersController::class);
    Route::resource('setting',\App\Http\Controllers\dashboard\SettingController::class);
    Route::resource('manufactur',\App\Http\Controllers\dashboard\ManufacturController::class);
    Route::resource('orders',\App\Http\Controllers\dashboard\OrdersController::class);
    Route::resource('cancelation',\App\Http\Controllers\dashboard\CancelationController::class);
    Route::resource('faqs',\App\Http\Controllers\dashboard\FaqsController::class);
    Route::get('edit-setting',[\App\Http\Controllers\dashboard\SettingController::class,'edit'])->name('edit.setting');
    Route::get('get-manufactur/{id}',[\App\Http\Controllers\dashboard\HomeController::class,'get_manufactur'])->name('get.manufactur');
    Route::put('update-setting',[\App\Http\Controllers\dashboard\SettingController::class,'update'])->name('update.setting');
    Route::get('accept-driver/{id}',[\App\Http\Controllers\dashboard\DriversController::class,'accept_driver']);

});
Route::get('/login','App\Http\Controllers\dashboard\LoginController@get')->name('login');
Route::post('login/post','App\Http\Controllers\dashboard\LoginController@post')->name('login.post');
Route::get('/logout','App\Http\Controllers\dashboard\LoginController@logout')->name('logout');

Route::get('passport', function () {

    Artisan::call('passport:install');

    dd("passport");

});
Route::get('migration', function () {

    Artisan::call('migrate');

    dd("migration Done"); //https://mnkaf.qa/api/migration

});
});
