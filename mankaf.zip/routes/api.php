<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::middleware("localization")->group(function () {
    Route::get('all-countries', [App\Http\Controllers\api\HomeController::class, 'countries']);
    Route::post('user-register', [App\Http\Controllers\api\HomeController::class, 'user_register']);

    Route::post('resend-otp', [App\Http\Controllers\api\HomeController::class, 'resend_otp']);
    Route::post('user-verify', [App\Http\Controllers\api\HomeController::class, 'user_verify']);
    Route::post('user-verify-new', [App\Http\Controllers\api\HomeController::class, 'user_verify_new']);
    Route::post('user-login', [App\Http\Controllers\api\HomeController::class, 'user_login']);
    Route::get('get-user', [App\Http\Controllers\api\HomeController::class, 'get_user']);
    Route::post('update-user', [App\Http\Controllers\api\HomeController::class, 'update_user']);
    Route::post('update-password', [App\Http\Controllers\api\HomeController::class, 'update_password']);
    Route::post('update-driver-password', [App\Http\Controllers\api\driver\DriverController::class, 'update_driver_password']);
    Route::get('user-logout', [App\Http\Controllers\api\HomeController::class, 'user_logout']);
    Route::post('forget-password', [App\Http\Controllers\api\HomeController::class, 'forget_password']);
    Route::post('forget-user-password-new', [App\Http\Controllers\api\HomeController::class, 'forget_user_password_new']);
    Route::post('reset-password', [App\Http\Controllers\api\HomeController::class, 'reset_password']);
    Route::get('all-users', [App\Http\Controllers\api\admin\AdminController::class, 'all_users']);
    Route::post('update-status', [App\Http\Controllers\api\admin\AdminController::class, 'update_status']);
    Route::get('all-vehicles', [App\Http\Controllers\api\driver\DriverController::class, 'vehicles_type']);
    Route::get('all-years', [App\Http\Controllers\api\HomeController::class, 'all_years']);
    Route::get('city/{country_id}', [App\Http\Controllers\api\HomeController::class, 'cities']);
    Route::post('models', [App\Http\Controllers\api\HomeController::class, 'models']);
    Route::post('driver-verify', [App\Http\Controllers\api\driver\DriverController::class, 'driver_verify']);
    Route::post('driver-verify-new', [App\Http\Controllers\api\driver\DriverController::class, 'driver_verify_new']);
    Route::post('driver-forget-password', [App\Http\Controllers\api\driver\DriverController::class, 'forget_password']);
    Route::post('forget-driver-password-new', [App\Http\Controllers\api\driver\DriverController::class, 'forget_driver_password_new']);
    Route::post('driver-login', [App\Http\Controllers\api\driver\DriverController::class, 'driver_login']);
    Route::get('driver-logout', [App\Http\Controllers\api\driver\DriverController::class, 'driver_logout']);
    Route::post('driver-reset-password', [App\Http\Controllers\api\driver\DriverController::class, 'reset_password']);
    Route::middleware('auth:driver')->group(function () {
        Route::post('driver-documents', [App\Http\Controllers\api\driver\DriverController::class, 'driver_documents']);
        Route::post('update-driver', [App\Http\Controllers\api\driver\DriverController::class, 'update_driver']);
        Route::post('driver-captin', [App\Http\Controllers\api\driver\DriverController::class, 'driver_captin']);
        Route::post('driver-register', [App\Http\Controllers\api\driver\DriverController::class, 'driver_register']);
        Route::get('driver_dashboard', [App\Http\Controllers\api\driver\DriverController::class, 'driver_dashboard']);
        Route::get('get-requests', [App\Http\Controllers\api\driver\DriverController::class, 'get_requests']);
        Route::post('accept-requests', [App\Http\Controllers\api\driver\DriverController::class, 'accept_requests']);
        Route::post('reject-requests', [App\Http\Controllers\api\driver\DriverController::class, 'reject_requests']);
        Route::get('get-notification', [App\Http\Controllers\api\driver\DriverController::class, 'get_notification']);
        Route::post('start-order', [App\Http\Controllers\api\driver\DriverController::class, 'start_order']);
        Route::post('finish-order', [App\Http\Controllers\api\driver\DriverController::class, 'finish_order']);
        Route::get('driver-cancelation', [App\Http\Controllers\api\driver\DriverController::class, 'driver_cancelation']);
        Route::post('cancel-order', [App\Http\Controllers\api\driver\DriverController::class, 'cancel_order']);
        Route::get('get-orders', [App\Http\Controllers\api\driver\DriverController::class, 'get_orders']);
        Route::get('get-driver-transactions', [App\Http\Controllers\api\driver\DriverController::class, 'get_driver_transactions']);
        Route::post('driver-status', [App\Http\Controllers\api\driver\DriverController::class, 'driver_longitude']);
        Route::get('get-driver-faqs', [App\Http\Controllers\api\driver\DriverController::class, 'get_driver_faqs']);
        Route::post('delete-driver-notification', [App\Http\Controllers\api\driver\DriverController::class, 'delete_driver_notification']);
        Route::post('driver-message', [App\Http\Controllers\api\driver\DriverController::class, 'driver_message']);
        Route::get('get-driver-chat', [App\Http\Controllers\api\driver\DriverController::class, 'get_driver_chat']);
        Route::get('driver-orders-history', [App\Http\Controllers\api\driver\DriverController::class, 'driver_orders_history']);
        Route::get('get-driver-order', [App\Http\Controllers\api\driver\DriverController::class, 'get_driver_order']);
        Route::post('driver-waiting', [App\Http\Controllers\api\driver\DriverController::class, 'driver_waiting']);
        Route::post('user-rate', [App\Http\Controllers\api\users\UsersController::class, 'user_rate']);
        Route::get('completed-trips', [App\Http\Controllers\api\driver\DriverController::class, 'completed_trips']);



    });
    Route::post('driver-signup', [App\Http\Controllers\api\driver\DriverController::class, 'sign_up']);
    Route::post('driver-resend-otp', [App\Http\Controllers\api\driver\DriverController::class, 'driver_resend_otp']);
    Route::middleware('auth:api')->group(function () {
        Route::get('categories', [App\Http\Controllers\api\users\UsersController::class, 'categories']);
        Route::get('sliders', [App\Http\Controllers\api\users\UsersController::class, 'sliders']);
        Route::post('add-to-wallet', [App\Http\Controllers\api\users\UsersController::class, 'add_wallet']);
        Route::get('get-wallet', [App\Http\Controllers\api\users\UsersController::class, 'get_wallet']);
        Route::post('user-cancel-order', [App\Http\Controllers\api\users\UsersController::class, 'user_cancel_order']);
        Route::get('get-user-orders', [App\Http\Controllers\api\users\UsersController::class, 'get_user_orders']);
        Route::post('user-pay', [App\Http\Controllers\api\users\UsersController::class, 'user_pay']);
        Route::get('user-notifications', [App\Http\Controllers\api\users\UsersController::class, 'user_notifications']);
        Route::post('driver-rate', [\App\Http\Controllers\api\users\UsersController::class, 'driver_comment']);
        Route::get('get-user-faqs', [App\Http\Controllers\api\users\UsersController::class, 'get_user_faqs']);
        Route::post('user-message', [App\Http\Controllers\api\users\UsersController::class, 'user_message']);
        Route::get('get-user-chat', [App\Http\Controllers\api\users\UsersController::class, 'get_user_chat']);
        Route::get('get-user-order', [App\Http\Controllers\api\users\UsersController::class, 'get_user_order']);
        Route::get('delete-order', [App\Http\Controllers\api\users\UsersController::class, 'delete_order']);

    });
    Route::get('setting', [App\Http\Controllers\api\HomeController::class, 'setting']);
    Route::get('manufacturers', [App\Http\Controllers\api\HomeController::class, 'manufacturers']);
    Route::post('orders', [App\Http\Controllers\api\HomeController::class, 'orders']);
    Route::get('user-cancelation', [App\Http\Controllers\api\users\UsersController::class, 'user_cancelation']);
    Route::post('delete-user-notification', [App\Http\Controllers\api\users\UsersController::class, 'delete_user_notification']);


});


