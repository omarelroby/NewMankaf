<?php

namespace App\DataTables;

use App\Models\Category;
use App\Models\Country;
use App\Models\Driver;
use App\Models\Models;
use App\Models\User;
use App\Models\VehicleType;
use App\Models\Year;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class DriversDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     * @return \Yajra\DataTables\EloquentDataTable
     */
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return datatables()
            ->eloquent($query)

            ->editColumn('country_id', function($q) {
                return $q->country->name??'';
            })
            ->editColumn('identity', function($q) {
                return $q->captin->identity??'';
            })
            ->editColumn('identity_expiry', function($q) {
                return $q->captin->identity_expiry??'';
            })
            ->editColumn('passport_number', function($q) {
                return $q->captin->passport_number??'';
            })
            ->editColumn('address', function($q) {
                return $q->captin->address??'';
            })
            ->editColumn('city_id', function($q) {
                return $q->captin->city->name??'';
            })
            ->editColumn('captin_country', function($q) {
                return $q->captin->country->name??'';
            })
            ->editColumn('vehicle_number', function($q) {
                return $q->captin->vehicle_number??'';
            })
            ->editColumn('vehicle_expiry', function($q) {
                return $q->captin->vehicle_expiry??'';
            })
            ->editColumn('vehicle_owner_name', function($q) {
                return $q->captin->vehicle_owner_name??'';
            })
            ->editColumn('year_id', function($q) {
                return $q->captin->years->name??'';
            })
            ->editColumn('model_id', function($q) {
                return $q->captin->models->name??'';
            })
            ->editColumn('vehicle_type_id', function($q) {
                return $q->captin->vehicles->name??'';
            }) ->editColumn('make_id', function($q) {
                return $q->captin->manufactur->name??'';
            })
            ->editColumn('passport_expiry', function($q) {
                return $q->captin->passport_expiry ??'';
            })
            ->editColumn('front_id_uploaded',  function($q)
            {
                    return $q->document ?'<a target="_blank" href="'.asset('public/'.$q->document->front_id_uploaded).'">view</a>':' ' ;
            })
            ->editColumn('back_id_uploaded',  function($q)
            {
                return $q->document ?'<a target="_blank" href="'.asset('public/'.$q->document->back_id_uploaded).'">view</a>':' ' ;
            })
            ->editColumn('driving_license_card_front',  function($q)
            {
                return $q->document ?'<a target="_blank" href="'.asset('public/'.$q->document->driving_license_card_front).'">view</a>':' ' ;
            })
            ->editColumn('driving_license_card_back',  function($q)
            {
                return $q->document ?'<a target="_blank" href="'.asset('public/'.$q->document->driving_license_card_back).'">view</a>':' ' ;
            })
            ->editColumn('vehicle_book_front',  function($q)
            {
                return $q->document ?'<a target="_blank" href="'.asset('public/'.$q->document->vehicle_book_front).'">view</a>':' ' ;
            })
            ->editColumn('vehicle_book_back',  function($q)
            {
                return $q->document ?'<a target="_blank" href="'.asset('public/'.$q->document->vehicle_book_back).'">view</a>':' ' ;
            })
            ->editColumn('status',  function($q) {
                if ($q->status == 'approved' ||$q->status=='APPROVED' )
                {
                    return '<div style="background-color: green;color: white;border-radius: 5px;padding: 5px;">' . "APPROVED" . '</div>';

                }
                else
                {
                    return '<div style="background-color:#c3c322;color: white; border-radius: 5px;padding: 5px;">' . "PENDING" . '</div>';

                }

            })
            ->addColumn('action', 'dashboard.drivers.actions')
            ->rawColumns(['action','status','front_id_uploaded','back_id_uploaded','driving_license_card_front','driving_license_card_back','vehicle_book_front','vehicle_book_back']);
    }

    /**
     * Get query source of dataTable.
     *
     * @param \App\Models\Category $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(Driver $model): QueryBuilder
    {
        return $model->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html(): HtmlBuilder
    {
        return $this->builder()
                    ->setTableId('users-table')
                    ->columns($this->getColumns())
                    ->minifiedAjax()
                     ->orderBy(0)
                    ->selectStyleSingle()
                    ->buttons([
                        Button::make('excel'),
                        Button::make('csv'),
                        Button::make('pdf'),
                        Button::make('print'),
                        Button::make('reset'),
                        Button::make('reload')
                    ]);
    }

    /**
     * Get the dataTable columns definition.
     *
     * @return array
     */
    public function getColumns(): array
    {
        return [

            Column::make('id'),
            Column::make('name')
                ->title(__('dashboard.name')),
            Column::make('email')
                ->title(__('dashboard.email')),
            Column::make('phone')
                ->title(__('dashboard.phone')),
            Column::make('country_id')
                ->title(__('dashboard.countries')),
            Column::make('identity')
                ->title(__('dashboard.identity')),
            Column::make('identity_expiry')
                ->title(__('dashboard.identity_expiry')),
            Column::make('passport_number')
                ->title(__('dashboard.passport_number')),
            Column::make('address')
                ->title(__('dashboard.address')),
            Column::make('city_id')
                ->title(__('dashboard.city_id')),
            Column::make('captin_country')
                ->title(__('dashboard.captin_country')),
            Column::make('vehicle_number')
                ->title(__('dashboard.vehicle_number')),
            Column::make('vehicle_expiry')
                ->title(__('dashboard.vehicle_expiry')),
            Column::make('vehicle_owner_name')
                ->title(__('dashboard.vehicle_owner_name')),
            Column::make('model_id')
                ->title(__('dashboard.model_id')),
            Column::make('year_id')
                ->title(__('dashboard.year_id')),
            Column::make('vehicle_type_id')
                ->title(__('dashboard.vehicle_type_id')),
            Column::make('make_id')
                ->title(__('dashboard.make_id')),
            Column::make('passport_expiry')
                ->title(__('dashboard.passport_expiry')),
            Column::make('front_id_uploaded')
                ->title(__('dashboard.front_id_uploaded')),
            Column::make('back_id_uploaded')
                ->title(__('dashboard.back_id_uploaded')),
            Column::make('driving_license_card_front')
                ->title(__('dashboard.driving_license_card_front')),
            Column::make('driving_license_card_back')
                ->title(__('dashboard.driving_license_card_back')),
            Column::make('vehicle_book_front')
                ->title(__('dashboard.vehicle_book_front')),
            Column::make('vehicle_book_back')
                ->title(__('dashboard.vehicle_book_back')),
            Column::make('status')
                ->title(__('dashboard.status')),
            Column::computed(__('action'))
                ->title(__('dashboard.action'))
                ->exportable(false)
                ->printable(false)
                ->width(60)
                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Users_' . date('YmdHis');
    }
}
