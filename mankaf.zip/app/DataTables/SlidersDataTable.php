<?php

namespace App\DataTables;

use App\Models\Category;
use App\Models\Country;
use App\Models\Sliders;
use App\Models\VehicleType;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class SlidersDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     * @return \Yajra\DataTables\EloquentDataTable
     */
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return datatables()
            ->eloquent($query)
            ->editColumn('main_address(ar)', function($q) {
                return $q->translate('ar')->main_address;
            })
            ->editColumn('main_address(en)', function($q) {
                return $q->translate('en')->main_address;
            })

            ->editColumn('sub_address(ar)', function($q) {
                return $q->translate('ar')->sub_address;
            })
            ->editColumn('sub_address(en)', function($q) {
                return $q->translate('en')->sub_address;
            })
            ->addColumn('image', function ($q) {
                $url= asset($q->image);
                return '<img src="'.$url.'" border="0" width="150" class="img-rounded" align="center"/>';
            })

            ->addColumn('action', 'dashboard.sliders.actions')
            ->rawColumns(['action','image']);
    }

    /**
     * Get query source of dataTable.
     *
     * @param \App\Models\Category $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(Sliders $model): QueryBuilder
    {
        return $model->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html(): HtmlBuilder
    {
        return $this->builder()
                    ->setTableId('category-table')
                    ->columns($this->getColumns())
                    ->minifiedAjax()
                     ->orderBy(0)
                    ->selectStyleSingle()
                    ->buttons([
                        Button::make('excel'),
                        Button::make('csv'),
                        Button::make('pdf'),
                        Button::make('print'),
                        Button::make('reset'),
                        Button::make('reload')
                    ]);
    }

    /**
     * Get the dataTable columns definition.
     *
     * @return array
     */
    public function getColumns(): array
    {
        return [

            Column::make('id'),
            Column::make('main_address(ar)')
                ->title(__('dashboard.main_address')),
            Column::make('main_address(en)')
                ->title(__('dashboard.main_address')),
            Column::make('sub_address(ar)')
                ->title(__('dashboard.sub_address')),
            Column::make('sub_address(en)')
                ->title(__('dashboard.sub_address')),
            Column::make('image')
                ->title(__('dashboard.image')),
            Column::computed(__('action'))
                ->title(__('dashboard.action'))
                ->exportable(false)
                ->printable(false)
                ->width(60)
                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Sliders_' . date('YmdHis');
    }
}
