<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class OrderShipmentStatusUpdated implements ShouldBroadcast
{
    public $order;



    public function broadcastOn()
    {
        return new Channel('orders.'.$this->order->id);
    }
}
