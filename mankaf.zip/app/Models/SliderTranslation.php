<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class SliderTranslation extends Model
{

    public $timestamps = false;
    protected $table='slider_translations';
    protected $fillable = ['main_address','sub_address'];
}
