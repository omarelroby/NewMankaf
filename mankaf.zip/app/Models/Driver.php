<?php

namespace App\Models;

use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class Driver extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'drivers';
    protected $appends = ['registered'];

    protected $fillable = [
        'id',
        'name',
        'email',
        'password',
        'country_id',
        'phone',
        'confirmation_code',
        'verify',
        'status',
        'birthday',
        'longitude',
        'latitude',
        'image',
        'is_online',
        'fcm_token',
        'balance',
        'avg_rate',
        'new_password',
    ];

    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id');
    }

    public function order()
    {
        return $this->hasOne(Orders::class, 'driver_id')->where('status','accepted')->orderBy('id','desc')->with('driver');
    }
    public function orders()
    {
        return $this->hasMany(Orders::class, 'driver_id');
    }

    public function canceled_orders()
    {
        return $this->hasMany(Orders::class, 'driver_id')->where('status','Canceled');
    }

    public function accepted()
    {
        return $this->hasMany(DriverRequests::class, 'driver_id')->where('status','approved');
    }
    public function total_requests()
    {
        return $this->hasMany(DriverRequests::class, 'driver_id');
    }

    public function captin()
    {
        return $this->hasOne(Captin::class);
    }

    public function document()
    {
        return $this->hasOne(DocumentsDriver::class);
    }
    public function getRegisteredAttribute()
    {
        if (!$this->email)
            return 'step 1';

        if (!$this->captin)
            return 'step 2';

        if (!$this->document)
            return 'step 3';

        return 'registered';

    }

}
