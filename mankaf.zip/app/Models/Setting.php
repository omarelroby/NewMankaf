<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
     protected $table='setting';
     protected $fillable=['currency','google_map_key','price_kilo'];
    public $timestamps = false;


}
