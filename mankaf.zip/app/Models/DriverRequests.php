<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class DriverRequests extends Model
{


    protected $table='driver_requests';
     protected $fillable=
         [
         'id',
         'driver_id',
         'order_id',
         'status',
         ];
     public function orders()
     {
         return $this->belongsTo(Orders::class,'order_id');
     }
     public function drivers()
     {
         return $this->belongsTo(Driver::class,'driver_id');
     }




}
