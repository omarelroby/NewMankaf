<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class VehicleTypeTranslation extends Model
{

    public $timestamps = false;
    protected $table='vehicle_type_translations';
    protected $fillable = ['name'];
}
