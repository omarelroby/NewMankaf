<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class Manufactur extends Model implements TranslatableContract
{
    use Translatable;
    protected $table='manufactur';
    public $translatedAttributes = ['name'];
    protected $fillable=['vehicle_type_id','image'];
    public function vehicle()
    {
        return $this->belongsTo(VehicleType::class,'vehicle_type_id');
    }

}
