<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $table='driver_notification';
     protected $fillable=[
         'driver_id',
         'title',
         'body',
         'image',
         'color',
         'read',

     ];



}
