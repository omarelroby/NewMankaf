<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class UserNotification extends Model
{
    protected $table='user_notifications';
     protected $fillable=[
         'user_id',
         'title',
         'body',
         'image',
         'read',
         'color',

     ];



}
