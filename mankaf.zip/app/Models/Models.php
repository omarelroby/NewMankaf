<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class Models extends Model implements TranslatableContract
{
    use Translatable;
    protected $table='models';
    public $translatedAttributes = ['name'];
    protected $fillable=['vehicle_type_id','manufactur_id'];
    public function vehicle()
    {
        return $this->belongsTo(VehicleType::class,'vehicle_type_id');
    }
    public function manufactur()
    {
        return $this->belongsTo(Manufactur::class,'manufactur_id');
    }

}
