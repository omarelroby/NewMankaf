<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class Cancelation extends Model
{
    protected $table='cancelation';
     protected $fillable=[
         'type',
         'reason',

     ];





}
