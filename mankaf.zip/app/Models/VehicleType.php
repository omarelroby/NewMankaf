<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class VehicleType extends Model implements TranslatableContract
{
    use Translatable;
    protected $table='vehicle_type';
    public $translatedAttributes = ['name'];
    protected $fillable=['id','image','category_id','price_per_kilo','driver_commission'];
    public function models()
    {
        return $this->hasMany(Models::class,'vehicle_type_id');
    }
    public function vehicles()
    {
        return $this->hasMany(VehicleType::class,'vehicle_type_id');
    }
    public function categories()
    {
        return $this->belongsTo(Category::class,'category_id');
    }


}
