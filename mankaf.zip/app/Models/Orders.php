<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    protected $table='orders';
     protected $fillable=[
         'user_id',
         'pick_up_longitude',
         'pick_up_latitude',
         'destination_longitude',
         'destination_latitude',
         'number_of_kilo',
         'time_in_minutes',
         'price',
         'vehicle_type_id',
         'driver_id',
         'status',
         'code',
         'reason_id',
         'comment',
         'cancelled_by',
         'pickup_name',
         'destination_name',
         'paid',
         'driver_commision',
         'payment_method',
         'completed_at',

     ];
    public function vehicles()
    {
        return $this->belongsTo(VehicleType::class,'vehicle_type_id');
    }
    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }
    public function driver()
    {
        return $this->belongsTo(Driver::class,'driver_id');
    }





}
