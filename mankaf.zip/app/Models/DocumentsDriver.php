<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class DocumentsDriver extends Model
{
    protected $table='driver_documents';
     protected $fillable=[
         'front_id_uploaded',
         'back_id_uploaded',
         'driving_license_card_front',
         'driving_license_card_back',
         'vehicle_book_front',
         'vehicle_book_back',
         'driver_id',

     ];
        public function driver()
        {
            return $this->belongsTo(Driver::class,'driver_id');
        }



}
