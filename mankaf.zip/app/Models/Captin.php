<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class Captin extends Model
{
    protected $table='captins';
     protected $fillable=[
         'identity',
         'identity_expiry',
         'passport_number',
         'address',
         'city_id',
         'country_id',
         'vehicle_number',
         'vehicle_expiry',
         'vehicle_owner_name',
         'model_id',
         'year_id',
         'driver_id',
         'vehicle_type_id',
         'make_id',
         'passport_expiry',
     ];
     public function manufactur()
     {
         return $this->belongsTo(Manufactur::class,'make_id');
     }
    public function vehicles()
    {
        return $this->belongsTo(VehicleType::class,'vehicle_type_id');
    }
    public function models()
    {
        return $this->belongsTo(Models::class,'model_id');
    }
    public function years()
    {
        return $this->belongsTo(Year::class,'year_id');
    }
    public function driver()
    {
        return $this->belongsTo(Driver::class,'driver_id');
    }
    public function city()
    {
        return $this->belongsTo(City::class,'city_id');
    }
    public function country()
    {
        return $this->belongsTo(Country::class,'country_id');
    }




}
