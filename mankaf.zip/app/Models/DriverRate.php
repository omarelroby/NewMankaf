<?php

namespace App\Models;

use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class DriverRate extends Model
{
    protected $table='driver_rate';
     protected $fillable=[
         'driver_id',
         'rate',
         'comment',
         'user_id',

     ];





}
