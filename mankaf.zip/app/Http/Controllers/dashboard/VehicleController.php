<?php

namespace App\Http\Controllers\dashboard;

use App\DataTables\CityDataTable;
use App\DataTables\CountriesDataTable;
use App\DataTables\VehiclesDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Http\Requests\CountryRequest;
use App\Models\Category;
use App\Models\City;
use App\Models\Country;
use App\Models\VehicleType;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Models\Languages;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use RealRashid\SweetAlert\Facades\Alert;
use App\DataTables\CategoriesDataTable;
use Illuminate\Support\Facades\Storage;



class VehicleController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(VehiclesDataTable $dataTable)
    {
         return $dataTable->render('dashboard.vehicles.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $categories=Category::all();
         return  view('dashboard.vehicles.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        if ($request->has('image')){
            $path='public/vehicles';
            $file=$request->file('image')->getClientOriginalExtension();
            $name = time().'.'.$file;
            $data['image'] = $request->file('image')->move($path,$name);

        }
        VehicleType::create($data) ;

        Alert::success('Success',__('dashboard.success'));
        return redirect()->route('vehicle-type.index');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $vehicle=VehicleType::find($id);
        $categories=Category::all();
        return  view('dashboard.vehicles.edit',compact('vehicle','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $vehicle=VehicleType::find($id);
        $data=$request->all();
        if ($request->has('image')){
            $path='public/vehicles';
            $file=$request->file('image')->getClientOriginalExtension();
            $name = time().'.'.$file;
            $data['image'] = $request->file('image')->move($path,$name);

        }
        $vehicle->update($data);
        $vehicle->save();
        Alert::success('UPDATED',__('dashboard.update'));
        return redirect()->route('vehicle-type.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        VehicleType::find($id)->delete();
        Alert::error('Deleted',__('dashboard.deleted'));
        return redirect()->route('vehicle-type.index');
    }
}
