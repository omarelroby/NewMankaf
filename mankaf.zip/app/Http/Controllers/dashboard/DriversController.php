<?php

namespace App\Http\Controllers\dashboard;

use App\DataTables\CityDataTable;
use App\DataTables\CountriesDataTable;
use App\DataTables\DriversDataTable;
use App\DataTables\ModelsDataTable;
use App\DataTables\UsersDataTable;
use App\DataTables\VehiclesDataTable;
use App\DataTables\YearsDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Http\Requests\CountryRequest;
use App\Models\Category;
use App\Models\City;
use App\Models\Country;
use App\Models\Driver;
use App\Models\Models;
use App\Models\Notification;
use App\Models\User;
use App\Models\VehicleType;
use App\Models\Year;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Models\Languages;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use RealRashid\SweetAlert\Facades\Alert;
use App\DataTables\CategoriesDataTable;
use Illuminate\Support\Facades\Storage;



class DriversController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(DriversDataTable $dataTable)
    {
         return $dataTable->render('dashboard.drivers.index');
    }


    public function destroy($id)
    {
        Driver::find($id)->delete();
        Alert::error('Deleted',__('dashboard.deleted'));
        return redirect()->route('drivers.index');
    }
    public function accept_driver($id)
    {
        $driver=Driver::find($id);
        $driver->update(['status'=>'APPROVED']);
        $datapayload= array('driver_id' => $id);
        $name=$driver->name;
        $data = array(
            'title'=>'تم قبولك',
            'sound' => "default",
            'data'=>$datapayload,
            'body'=>'تم قبولك في تطبيق منكف.'.$name.'أهلا بك ',
            'color' => "#79bc64"
        );
        $fields = array(
            'registration_ids'=>$driver->fcm_token,
            'notification'=>$data,
            'data'=>$datapayload,
            "priority" => "high",
        );
        $headers = array(
            'Authorization: key=AAAA3uSxKr0:APA91bG3_UiRC8jfVrbVAI9FJGXgdeXellR1H4KTmbMjPC62AS2KEPlPDsZcKSgvjVaGMiy1UNi3ZKKCU9rgATDftR6VNmUSfqFNktudqiJSBnTFHinEz46-TECqjcElK0vZwxg8xKJg',
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_exec($ch);
        curl_close( $ch );
        Notification::create([
            'driver_id'=>$id,
            'title'=>$data['title'],
            'body'=>$data['body'],
            'image'=>'images/star.svg',
            'color'=>'#636363',

        ]);
        Alert::success('Deleted',__('dashboard.update'));
        return redirect()->back();
    }
}
