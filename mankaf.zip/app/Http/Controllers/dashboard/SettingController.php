<?php

namespace App\Http\Controllers\dashboard;

use App\DataTables\CityDataTable;
use App\DataTables\CountriesDataTable;
use App\DataTables\ModelsDataTable;
use App\DataTables\SettingDataTable;
use App\DataTables\SlidersDataTable;
use App\DataTables\VehiclesDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Http\Requests\CountryRequest;
use App\Models\Category;
use App\Models\City;
use App\Models\Country;
use App\Models\Models;
use App\Models\Setting;
use App\Models\Sliders;
use App\Models\VehicleType;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Models\Languages;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use RealRashid\SweetAlert\Facades\Alert;
use App\DataTables\CategoriesDataTable;
use Illuminate\Support\Facades\Storage;



class SettingController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(SettingDataTable $dataTable)
    {
         return $dataTable->render('dashboard.setting.index');
    }



    public function edit()
    {

        $setting=Setting::first();
         return  view('dashboard.setting.edit',compact('setting'));
    }


    public function update(Request $request)
    {
        $setting=Setting::first();
        if ($setting)
        {
            $setting->update([
                'currency'=>$request->currency,
                'google_map_key'=>$request->google_map_key,
                'price_kilo'=>$request->price_kilo,
            ]);
        }
        else
        {
            Setting::create([
                'currency'=>$request->currency,
                'google_map_key'=>$request->google_map_key,
                'price_kilo'=>$request->price_kilo,
        ]);
        }

         Alert::success('UPDATED',__('dashboard.update'));
        return redirect()->route('setting.index');
    }



}
