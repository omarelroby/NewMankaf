<?php

namespace App\Http\Controllers\dashboard;

use App\DataTables\CityDataTable;
use App\DataTables\CountriesDataTable;
use App\DataTables\ModelsDataTable;
use App\DataTables\VehiclesDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Http\Requests\CountryRequest;
use App\Models\Category;
use App\Models\City;
use App\Models\Country;
use App\Models\Manufactur;
use App\Models\Models;
use App\Models\VehicleType;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Models\Languages;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use RealRashid\SweetAlert\Facades\Alert;
use App\DataTables\CategoriesDataTable;
use Illuminate\Support\Facades\Storage;



class ModelsController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ModelsDataTable $dataTable)
    {
         return $dataTable->render('dashboard.models.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $vehicles=VehicleType::all();
         return  view('dashboard.models.create',compact('vehicles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        Models::create($data) ;
        Alert::success('Success',__('dashboard.success'));
        return redirect()->route('models.index');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $models=Models::find($id);
        $vehicles=VehicleType::all();
        $manufactur=Manufactur::where('vehicle_type_id',$models->vehicle_type_id)->get();
        return  view('dashboard.models.edit',compact('vehicles','models','manufactur'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $models=Models::find($id);
        $data=$request->all();
        $models->update($data);
        $models->save();
        Alert::success('UPDATED',__('dashboard.update'));
        return redirect()->route('models.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Models::find($id)->delete();
        Alert::error('Deleted',__('dashboard.deleted'));
        return redirect()->route('models.index');
    }
}
