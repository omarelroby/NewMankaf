<?php

namespace App\Http\Controllers\dashboard;

use App\DataTables\CityDataTable;
use App\DataTables\CountriesDataTable;
use App\DataTables\DriversDataTable;
use App\DataTables\ModelsDataTable;
use App\DataTables\OrdersDataTable;
use App\DataTables\UsersDataTable;
use App\DataTables\VehiclesDataTable;
use App\DataTables\YearsDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Http\Requests\CountryRequest;
use App\Models\Category;
use App\Models\City;
use App\Models\Country;
use App\Models\Driver;
use App\Models\Models;
use App\Models\Orders;
use App\Models\User;
use App\Models\VehicleType;
use App\Models\Year;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Models\Languages;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use RealRashid\SweetAlert\Facades\Alert;
use App\DataTables\CategoriesDataTable;
use Illuminate\Support\Facades\Storage;



class OrdersController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(OrdersDataTable $dataTable)
    {
         return $dataTable->render('dashboard.orders.index');
    }


    public function destroy($id)
    {
        Orders::find($id)->delete();
        Alert::error('Deleted',__('dashboard.deleted'));
        return redirect()->route('orders.index');
    }
}
