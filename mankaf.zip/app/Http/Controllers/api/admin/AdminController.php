<?php

namespace App\Http\Controllers\api\admin;

use App\Http\Resources\CountryResource;
use App\Http\Resources\UserResource;
use App\Http\Resources\VehiclesTypeResource;
use App\Models\Country;
use App\Models\User;
use App\Models\VehicleType;
use App\Traits\Response;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class AdminController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    use Response;


    public function all_users()
    {
        $users = User::all();
        return $this->success(UserResource::collection($users));
    }
    public function vehicles_type()
    {
        $vehicles = VehicleType::all();
        return $this->success(VehiclesTypeResource::collection($vehicles));
    }







}
