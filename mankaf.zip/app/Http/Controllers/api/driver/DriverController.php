<?php

namespace App\Http\Controllers\api\driver;

use App\Http\Resources\CancelationResource;
use App\Http\Resources\ChatResource;
use App\Http\Resources\ChatResourceCollection;
use App\Http\Resources\CompletedTripsResource;
use App\Http\Resources\DriverRequestsResource;
use App\Http\Resources\DriverResource;
use App\Http\Resources\FaqsResource;
use App\Http\Resources\NotificationResource;
use App\Http\Resources\NotificationResourceCollection;
use App\Http\Resources\OrdersResource;
use App\Http\Resources\OrdersResourceCollection;
use App\Http\Resources\VehiclesTypeResource;
use App\Http\Resources\WalletRequestResource;
use App\Models\Cancelation;
use App\Models\Captin;
use App\Models\Chat;
use App\Models\DocumentsDriver;
use App\Models\Driver;
use App\Models\DriverRequests;
use App\Models\Faqs;
use App\Models\Notification;
use App\Models\Orders;
use App\Models\User;
use App\Models\UserNotification;
use App\Models\VehicleType;
use App\Models\WalletRequest;
use App\Traits\Response;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use App\Events\OrderTracking;
use App\Events\OrderRequests;

class DriverController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    use Response;


    public function vehicles_type()
    {
        $vehicles = VehicleType::all();
        return $this->success(VehiclesTypeResource::collection($vehicles));
    }

    public function driver_register(Request $request)
    {
        $oValidatorRules =
            [
                'name' => 'required',
                'email' => 'required|unique:drivers,email',
                'day' => 'required',
                'month' => 'required',
                'year' => 'required',
                'country_id' => 'required|exists:countries,id',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $data = $request->all();
        $driver_id = auth('driver')->user()->id;
        $driver = Driver::find($driver_id);
        $birthday = $request->year . '-' . $request->month . '-' . $request->day;
        $code = rand(1000, 9999);
        $driver->update([
            'name' => $data['name'],
            'email' => $data['email'],
            'country_id' => $data['country_id'],
            'confirmation_code' => $code,
            'birthday' => $birthday,
        ]);
        $data =
            [
                'driver' => new DriverResource(auth('driver')->user())
            ];
        return $this->successMessage(__('messages.success'), $data);
    }

    public function driver_verify(Request $request)
    {
        $oValidatorRules =
            [
                'verification_code' => 'required',
                'phone' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver = Driver::where('phone', $request->phone)->first();
        if ($driver) {
            if ($driver->confirmation_code == $request->verification_code) {
                $driver->update([
                    'verify' => 1,
                    'confirmation_code' => null,
                ]);
                return $this->successMessage(__('messages.activation'), [
                    'token' => 'Bearer' . ' ' . $driver->createToken($driver->name)->accessToken,
                ]);
            } else {
                return $this->error(__('messages.error-active'));
            }


        } else {
            return $this->error(__('messages.check'));
        }
    }
    public function driver_verify_new(Request $request)
    {
        $oValidatorRules =
            [
                'verification_code' => 'required',
                'phone' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver = Driver::where('phone', $request->phone)->first();
        if ($driver) {
            if ($driver->confirmation_code == $request->verification_code) {
                $driver->update([
                    'verify' => 1,
                    'confirmation_code' => null,
                    'password'=>$driver->new_password,

                ]);
                $driver->update(['new_password'=>null]);
                return $this->successMessage(__('messages.activation'), [
                    'token' => 'Bearer' . ' ' . $driver->createToken($driver->name)->accessToken,
                    'driver'=>new DriverResource($driver)
                ]);
            } else {
                return $this->error(__('messages.error-active'));
            }


        } else {
            return $this->error(__('messages.check'));
        }
    }

    public function forget_password(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver = Driver::where('phone', $request->phone)->first();
        if ($driver) {
            $code = rand(1000, 9999);
            $driver->update(['confirmation_code' => $code]);
            return $this->successMessage(__('messages.send-code'), ['confirmation_code' => $code]);
        } else {
            return $this->error(__('messages.check'));
        }
    }
    public function forget_driver_password_new(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
                'new_password' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver = Driver::where('phone', $request->phone)->first();
        if ($driver)
        {
            $code = rand(1000, 9999);
            $driver->update(['confirmation_code' => $code,'new_password'=>bcrypt($request->new_password)]);
            return $this->successMessage(__('messages.send-code'), ['confirmation_code' => $code]);
        }
        else
        {
            return $this->error(__('messages.check'));
        }
    }

    public function driver_login(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
                'password' => 'required',
                'fcm_token' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver = Driver::where('phone', $request->phone)->first();
        if ($driver) {

            if ($driver->verify == 1) {
                if (Hash::check($request->password, $driver->password)) {
                    $driver->update(['fcm_token' => $request->fcm_token]);
                    $data =
                        [
                            'driver' => new DriverResource($driver),
                            'token' => 'Bearer' . ' ' . $driver->createToken($driver->name)->accessToken,
                        ];
                    return $this->successMessage(__('messages.success-login'), $data);
                } else {
                    return $this->error(__('messages.password-wrong'));
                }
            } else {
                return $this->error(__('messages.phone-not-active'));
            }
        } else {
            return $this->error(__('messages.error-phone'));
        }

    }

    public function reset_password(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
                'code' => 'required',
                'newPassword' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver = Driver::where('phone', $request->phone)->first();
        if ($driver)
        {
            if ($driver->confirmation_code == $request->code) {
                $driver->update([
                    'password' => bcrypt($request->newPassword),
                    'confirmation_code' => null,
                    'verify' => 1
                ]);
                $data=[
                    'driver'=>new DriverResource($driver),
                    'token'=>$driver->createToken($driver->name)->accessToken
                ];
                return $this->successMessage(__('messages.changed-password'),[$data]);
            }
            else
            {
                return $this->error(__('messages.error-active'));
            }
        } else {
            return $this->error(__('messages.check'));

        }
    }

    public function driver_captin(Request $request)
    {
        $oValidatorRules =
            [
                'identity' => 'required',
                'identity_expiry' => 'required',
                'passport_number' => 'required',
                'address' => 'required',
                'city_id' => 'required',
                'country_id' => 'required',
                'vehicle_number' => 'required',
                'vehicle_expiry' => 'required|date',
                'vehicle_owner_name' => 'required',
                'model_id' => 'required|exists:models,id',
                'year_id' => 'required|exists:years,id',
                'vehicle_type_id' => 'required|exists:vehicle_type,id',
                'passport_expiry' => 'required|date',

            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver_id = auth('driver')->user()->id;
        Captin::create(
            [
                'identity' => $request->identity,
                'driver_id' => $driver_id,
                'identity_expiry' => $request->identity_expiry,
                'passport_number' => $request->passport_number,
                'address' => $request->address,
                'city_id' => $request->city_id,
                'country_id' => $request->country_id,
                'vehicle_number' => $request->vehicle_number,
                'vehicle_expiry' => $request->vehicle_expiry,
                'vehicle_owner_name' => $request->vehicle_owner_name,
                'model_id' => $request->model_id,
                'year_id' => $request->year_id,
                'vehicle_type_id' => $request->vehicle_type_id,
                'passport_expiry' => $request->passport_expiry,

            ]
        );
        $data =
            [
                'driver' => new DriverResource(auth('driver')->user())
            ];
        return $this->successMessage(__('messages.success'), $data);

    }

    public function driver_documents(Request $request)
    {
        $oValidatorRules =
            [
                'front_id_uploaded' => 'required',
                'back_id_uploaded' => 'required',
                'driving_license_card_front' => 'required',
                'driving_license_card_back' => 'required',
                'vehicle_book_front' => 'required',
                'vehicle_book_back' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $data =
            [
                'front_id_uploaded' => $request->front_id_uploaded,
                'back_id_uploaded' => $request->back_id_uploaded,
                'driving_license_card_front' => $request->driving_license_card_front,
                'driving_license_card_back' => $request->driving_license_card_back,
                'vehicle_book_front' => $request->vehicle_book_front,
                'vehicle_book_back' => $request->vehicle_book_back,
                'driver_id' => auth('driver')->user()->id,
            ];
        if ($request->has('front_id_uploaded')) {
            $path = 'public/driverDocuments';
            $file = $request->file('front_id_uploaded')->getClientOriginalExtension();
            $file_name = time() . '.' . $file;
            $data['front_id_uploaded'] = $request->file('front_id_uploaded')->move($path, $file_name);
        }
        if ($request->has('back_id_uploaded')) {
            $path = 'public/driverDocuments';
            $file = $request->file('back_id_uploaded')->getClientOriginalExtension();
            $file_name = time() . '.' . $file;
            $data['back_id_uploaded'] = $request->file('back_id_uploaded')->move($path, $file_name);
        }
        if ($request->has('driving_license_card_front')) {
            $path = 'public/driverDocuments';
            $file = $request->file('driving_license_card_front')->getClientOriginalExtension();
            $file_name = time() . '.' . $file;
            $data['driving_license_card_front'] = $request->file('driving_license_card_front')->move($path, $file_name);
        }
        if ($request->has('driving_license_card_back')) {
            $path = 'public/driverDocuments';
            $file = $request->file('driving_license_card_back')->getClientOriginalExtension();
            $file_name = time() . '.' . $file;
            $data['driving_license_card_back'] = $request->file('driving_license_card_back')->move($path, $file_name);
        }
        if ($request->has('vehicle_book_front')) {
            $path = 'public/driverDocuments';
            $file = $request->file('vehicle_book_front')->getClientOriginalExtension();
            $file_name = time() . '.' . $file;
            $data['vehicle_book_front'] = $request->file('vehicle_book_front')->move($path, $file_name);
        }
        if ($request->has('vehicle_book_back')) {
            $path = 'public/driverDocuments';
            $file = $request->file('vehicle_book_back')->getClientOriginalExtension();
            $file_name = time() . '.' . $file;
            $data['vehicle_book_back'] = $request->file('vehicle_book_back')->move($path, $file_name);
        }
        DocumentsDriver::create($data);
        $data =
            [
                'driver' => new DriverResource(auth('driver')->user())
            ];
        return $this->successMessage(__('messages.success'), $data);
    }

    public function sign_up(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required|unique:drivers,phone',
                'password' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $data = $request->all();
        if ($request->has('password')) {
            $data['password'] = bcrypt($request->password);
        }
        $code = rand(1000, 9999);
        Driver::create([
            'password' => $data['password'],
            'phone' => $data['phone'],
            'confirmation_code' => $code,
        ]);
        return $this->successMessage(__('messages.success'), ['otp_code' => $code]);
    }

    public function driver_resend_otp(Request $request)
    {
        $driver = Driver::where('phone', $request->phone)->first();
        if ($driver) {
            $code = rand(1000, 9999);
            $driver->update(['confirmation_code' => $code]);
            return $this->successMessage(__('messages.send-code'), ['confirmation_code' => $code]);


        } else {
            return $this->error(__('messages.check'));
        }
    }

    public function driver_longitude(Request $request)
    {
        $driver_id = auth('driver')->user()->id;
        if ($request->is_online == "true") {
            $oValidatorRules =
                [
                    'longitude' => 'required',
                    'latitude' => 'required',
                ];
            $validator = Validator::make($request->all(), $oValidatorRules);
            if ($validator->fails()) {
                return $this->error($validator->errors()->first());
            }
            $driver = Driver::find($driver_id);
            $driver->update([
                'longitude' => $request->longitude,
                'latitude' => $request->latitude,
                'is_online' => 1,

            ]);
            if ($driver->order)
            {
                broadcast(new OrderTracking($driver->order));


            }
            return $this->successMessage(__('messages.success-update'), ['is_online' => true]);

        } else {
            $driver = Driver::find($driver_id);
            $driver->update(['is_online' => 0]);
            return $this->successMessage(__('messages.success-update'), ['is_online' => false]);
        }


    }

    public function driver_dashboard()
    {
        $total_orders = auth('driver')->user()->orders->count();
        $canceled_orders = auth('driver')->user()->canceled_orders->count();
        $approved_orders = auth('driver')->user()->accepted->count();

        if($total_orders==0)
        {
            $canceled=0;
        }
        else
        {
            $canceled=round($canceled_orders / $total_orders * 100);
        }

        if(auth('driver')->user()->total_requests->count()==0)
        {
            $approved=0;
        }
        else
        {
            $approved=round($approved_orders / auth('driver')->user()->total_requests->count() * 100);
        }

        return $this->successMessage("", ['canceled' =>$canceled , 'approved' =>$approved , 'rating' => auth('driver')->user()->avg_rate ? round(auth('driver')->user()->avg_rate) : 0, 'balance' => round((int)auth('driver')->user()->balance)]);


    }

    public function driver_logout()
    {
        $user = auth('driver')->user()->token();
        $user->revoke();
        return $this->successMessage(__('messages.success-logout'));
    }

    public function update_driver(Request $request)
    {
        $oValidatorRules =
            [
                'image' => 'nullable',
                'name' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $data = $request->all();
        $driver = Driver::find(\auth('driver')->user()->id);
        if ($request->has('image')) {
            $path = 'public/Driver';
            $ext = $request->file('image')->getClientOriginalExtension();
            $name = time() . '.' . $ext;
            $data['image'] = $request->file('image')->move($path, $name);
            $driver->update(['image' => $data['image']]);
        }
        $driver->update(['name' => $request->name]);
        return $this->successMessage(__('dashboard.update'), new DriverResource($driver));

    }

    public function update_driver_password(Request $request)
    {
        $oValidatorRules = [
            'old_password' => 'required',
            'new_password' => 'required',
        ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $driver = Driver::find(\auth('driver')->user()->id);
        if (!Hash::check($request->old_password, $driver->password)) {
            return $this->error(__('dashboard.check-password'));
        } else {
            $driver->update(['password' => bcrypt($request->new_password)]);
            return $this->successMessage(__('dashboard.updated-password'));
        }
    }

    public function get_requests()
    {
        $driver_id = \auth('driver')->user()->id;
        $requests = DriverRequests::where('driver_id', $driver_id)->orderBy('id', 'desc')->get();
        return $this->success(DriverRequestsResource::collection($requests));
    }

    public function accept_requests(Request $request)
    {
        $driver_id = \auth('driver')->user()->id;
        $driver = Driver::find($driver_id);
        $order = Orders::find($request->order_id);
        $DriverRequest = DriverRequests::where('order_id', $request->order_id)
            ->where('driver_id', $driver_id)->first();
        if ($DriverRequest) {
            $DriverRequest->update(
                ['status' => 'approved'],
            );
            $driver->update(
                ['status' => 'approved'],
            );
            $datapayload = array('order_id' => $order->id);
            $name = $driver->name;
            $data = array(
                'title' => 'تم الموافقة ع طلبك',
                'sound' => "default",
                'data' => $datapayload,
                'body' => $name . 'تم قبول طلبك من قبل '
            );
            $fields = array(
                'registration_ids' => $driver->fcm_token,
                'notification' => $data,
                'data' => $datapayload,
                "priority" => "high",
            );
            $headers = array(
                'Authorization: key=AAAA3uSxKr0:APA91bG3_UiRC8jfVrbVAI9FJGXgdeXellR1H4KTmbMjPC62AS2KEPlPDsZcKSgvjVaGMiy1UNi3ZKKCU9rgATDftR6VNmUSfqFNktudqiJSBnTFHinEz46-TECqjcElK0vZwxg8xKJg',
                'Content-Type: application/json'
            );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            curl_exec($ch);
            curl_close($ch);
            Notification::create([
                'driver_id' => $driver_id,
                'title' => $data['title'],
                'body' => $data['body'],
                'image' => 'images/note.svg',
                'color' => '#0DA600',

            ]);
            UserNotification::create([
                'user_id' => $order->user_id,
                'title' => $data['title'],
                'body' => $data['body'],
                'image' => 'images/note.svg',
                'color' => '#0DA600',

            ]);
            $otherRequests=DriverRequests::where('driver_id','!=',$driver_id)
                ->where('order_id',$request->order_id)->get();
            foreach ($otherRequests as $other)
            {
                $other->delete();
            }
            $code = mt_rand(1111, 9999);
            $order->update([
                'driver_id' => $driver_id,
                'status' => 'accepted',
                'code' => $code
            ]);
            return $this->successMessage(__('dashboard.update'), ['order' => new OrdersResource($order)]);
        } else {
            return $this->error(__('dashboard.error-request'));
        }


    }

    public function reject_requests(Request $request)
    {
        $driver_id = \auth('driver')->user()->id;
        $order = Orders::find($request->order_id);
        $DriverRequest = DriverRequests::where('order_id', $request->order_id)
            ->where('driver_id', $driver_id)->first();
        if ($DriverRequest) {
            $order->update([
                'status' => 'reject'
            ]);
            $DriverRequest->update(['status' => 'reject']);
            return $this->successMessage(__('dashboard.update'));

        } else {
            return $this->error(__('dashboard.error-request'));
        }
    }

    public function get_notification()
    {
        $driver_id = \auth('driver')->user()->id;
        $Notification = Notification::where('driver_id', $driver_id)->orderBy('id', 'desc')->paginate(10);
        return $this->successMessage(__('messages.notification-message'), [new NotificationResourceCollection($Notification)]);


    }

    public function start_order(Request $request)
    {
        $order = Orders::find($request->order_id);
        $driver = Driver::find($order->driver_id);
        if ($order) {
            if ($order->code != null) {
                if ($request->code == $order->code) {
                    $order->update(['status' => 'started']);
                    $data = array(
                        'title' => 'تم بدء رحلة جديدة',
                        'sound' => "default",
                        'data' => array('driver' => $driver->name),
                        'body' => $driver->name . 'تم بدء رحلة جديدة مع '
                    );
                    $fields = array(
                        'registration_ids' => $driver->fcm_token,
                        'notification' => $data,
                        'data' => array('driver' => $driver->name),
                        "priority" => "high",
                    );
                    $headers = array(
                        'Authorization: key=AAAA3uSxKr0:APA91bG3_UiRC8jfVrbVAI9FJGXgdeXellR1H4KTmbMjPC62AS2KEPlPDsZcKSgvjVaGMiy1UNi3ZKKCU9rgATDftR6VNmUSfqFNktudqiJSBnTFHinEz46-TECqjcElK0vZwxg8xKJg',
                        'Content-Type: application/json'
                    );
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                    curl_exec($ch);
                    curl_close($ch);
                    Notification::create([
                        'driver_id' => $driver->id,
                        'title' => $data['title'],
                        'body' => $data['body'],
                        'image' => 'images/note.svg',
                        'color' => '#0DA600',

                    ]);
                    UserNotification::create([
                        'user_id' => $order->user_id,
                        'title' => $data['title'],
                        'body' => $data['body'],
                        'image' => 'images/note.svg',
                        'color' => '#0DA600',
                    ]);
                    return $this->successMessage(__('messages.success-update'));
                } else {
                    return $this->error(__('messages.error-active'));
                }
            } else {
                return $this->error(__('messages.error-active'));
            }
        } else {
            return $this->error(__('messages.error-order'));
        }
    }

    public function finish_order(Request $request)
    {
        $order = Orders::find($request->order_id);
        $driver = Driver::find($order->driver_id);

        if ($order) {
            if ($order->status == 'started') {
                $order->update(['status' => 'completed','completed_at'=>now()->toDateTimeString()]);
                $data = array(
                    'title' => 'تم انتهاء الرحلة',
                    'sound' => "default",
                    'data' => array('driver' => $driver->name),
                    'body' => $driver->name . 'تم انتهاء الرحلة مع '
                );
                $fields = array(
                    'registration_ids' => $driver->fcm_token,
                    'notification' => $data,
                    'data' => array('driver' => $driver->name),
                    "priority" => "high",
                );
                $headers = array(
                    'Authorization: key=AAAA3uSxKr0:APA91bG3_UiRC8jfVrbVAI9FJGXgdeXellR1H4KTmbMjPC62AS2KEPlPDsZcKSgvjVaGMiy1UNi3ZKKCU9rgATDftR6VNmUSfqFNktudqiJSBnTFHinEz46-TECqjcElK0vZwxg8xKJg',
                    'Content-Type: application/json'
                );
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                curl_exec($ch);
                curl_close($ch);
                Notification::create([
                    'driver_id' => $driver->id,
                    'title' => $data['title'],
                    'body' => $data['body'],
                    'image' => 'images/note.svg',
                    'color' => '#0DA600',

                ]);
                UserNotification::create([
                    'user_id' => $order->user_id,
                    'title' => $data['title'],
                    'body' => $data['body'],
                    'image' => 'images/note.svg',
                    'color' => '#0DA600',

                ]);
                return $this->successMessage(__('messages.success-update'));

            } else {
                return $this->error(__('messages.error-order-finish'));
            }
        }

        else {
            return $this->error(__('messages.error-order'));
        }
    }

    public function driver_cancelation()
    {
        $driver_id = \auth('driver')->user()->id;
        $driver = Driver::find($driver_id);
        if ($driver)
        {
            $reasons = Cancelation::where('type', 'driver')->get();
            return $this->success(CancelationResource::collection($reasons));
        } else {
            return $this->error(__('messages.user-not-found'));
        }


    }

    public function cancel_order(Request $request)
    {
        $driver_id = \auth('driver')->user()->id;
        $driver = Driver::find($driver_id);
        $order = Orders::where('driver_id', $driver_id)
            ->where('id', $request->order_id)->first();
        $user = User::where('id', $order->user_id)->first();
        if ($order) {
            $order->update([
                'status' => 'canceled',
                'reason_id' => $request->reason_id,
                'comment' => $request->comment,
                'cancelled_by' => $driver->name,
            ]);
            $datapayload = array('order_id' => $order->id);
            $data = array(
                'title' => 'تم الغاء طلبك',
                'sound' => "default",
                'data' => $datapayload,
                'body' => "لسوء الحظ، اضطر سائقك إلى إلغاء الرحلة، يرجى طلب رحلة جديدة وسنقوم بنقلك قريبًا",
                'color' => "#79bc64"
            );

            $fields = array(
                'registration_ids' => $user->firebase_token,
                'notification' => $data,
                'data' => $datapayload,
                "priority" => "high",
            );
            $headers = array(
                'Authorization: key=AAAAR2GKiPM:APA91bEI2JzXop_BKhQJwhdXCJpKFk-M_bBo5DDS4JCDotkx_nlpbgLLsmjnUaJv0eVzjVGZlUrGB3WpUrCUbzrGKCiW47881QrlrIEcuB4ssxVqzUfYbEoDXzrcbq25GWjfbz1oLUXL',
                'Content-Type: application/json'
            );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            curl_exec($ch);
            curl_close($ch);
            UserNotification::create([
                'user_id' => $user->id,
                'title' => $data['title'],
                'body' => $data['body'],
                'image' => 'images/close.svg',
                'color' => '#E30000',
            ]);
            return $this->successMessage(__('messages.success-update'));

        } else {
            return $this->error(__('messages.user-not-found'));
        }


    }

    public function get_orders()
    {
        $driver_id = \auth('driver')->user()->id;
        $orders = Orders::where('driver_id', $driver_id)->orderBy('id', 'desc')->paginate(10);
        return $this->success(new OrdersResourceCollection($orders));

    }

    public function get_driver_transactions()
    {
        $driver_id = \auth('driver')->user()->id;
        $balance = Driver::find($driver_id)->balance;
        $transactions = WalletRequest::where('driver_id', $driver_id)->get();
        return $this->success(['Balance' => $balance, 'transactions' => WalletRequestResource::collection($transactions)]);
    }

    public function get_driver_faqs()
    {
        $driver_faqs = Faqs::where('type', 'driver')->get();
        return $this->success(FaqsResource::collection($driver_faqs));
    }

    public function delete_driver_notification(Request $request)
    {
        Notification::where('id', $request->notification_id)
            ->where('driver_id', \auth('driver')->user()->id)->delete();
        return $this->successMessage(__('dashboard.deleted'));
    }

    public function driver_message(Request $request)
    {
        $driver_id = \auth('driver')->user()->id;
        $oValidatorRules =
            [
                'user_id' => 'required',
                'order_id' => 'required',
                'driver_message' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $user = User::find($request->user_id);
        $datapayload = array('order_id' => $request->order_id);
        $data = array(
            'title' => 'لديك رسالة جديدة',
            'sound' => "default",
            'data' => $datapayload,
            'body' => $request->driver_message,
            'color' => "#79bc64"
        );

        $fields = array(
            'registration_ids' => $user->firebase_token,
            'notification' => $data,
            'data' => $datapayload,
            "priority" => "high",
        );
        $headers = array(
            'Authorization: key=AAAAR2GKiPM:APA91bEI2JzXop_BKhQJwhdXCJpKFk-M_bBo5DDS4JCDotkx_nlpbgLLsmjnUaJv0eVzjVGZlUrGB3WpUrCUbzrGKCiW47881QrlrIEcuB4ssxVqzUfYbEoDXzrcbq25GWjfbz1oLUXL',
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_exec($ch);
        curl_close($ch);
        Notification::create([
            'driver_id' => $driver_id,
            'title' => $data['title'],
            'body' => $data['body'],
            'image' => 'images/note.svg',
            'color' => '#0DA600',
        ]);
        Chat::create([
            'user_id' => $request->user_id,
            'order_id' => $request->order_id,
            'driver_message' => $request->driver_message,
            'driver_id' => $driver_id,
        ]);
        return $this->successMessage(__('messages.success'));


    }

    public function get_driver_chat(Request $request)
    {
        $driver_id = \auth('driver')->user()->id;
        $chat = Chat::where('order_id', $request->order_id)
            ->where('driver_id', $driver_id)->orderBy('id', 'desc')->paginate(10);
        return $this->success(new ChatResourceCollection($chat));

    }

    public function driver_orders_history()
    {
        $driver_id = \auth('driver')->user()->id;
        $orders = Orders::where('driver_id', $driver_id)->get();
        $last_order = Orders::where('driver_id', $driver_id)->
            where('status','completed')->latest()->first();
        $kilos = Orders::where('driver_id', $driver_id)->sum('number_of_kilo');
        $time = Orders::where('driver_id', $driver_id)->sum('time_in_minutes');
        $price = Orders::where('driver_id', $driver_id)
            ->whereDate('created_at', Carbon::today())->sum('driver_commision');
         $data = [
            'total_time_online' => $time,
            'total_trips' => $orders->count(),
            'total_distance' => $kilos,
            'driver_commisions' => $price,
            'last_trip_ended_at' =>  \Carbon\Carbon::parse($last_order->completed_at)->diffForHumans()??'',
        ];
        return $this->success($data);

    }

    public function get_driver_order(Request $request)
    {
        $order = Orders::where('id', $request->order_id)->where('driver_id', \auth('driver')->user()->id)->first();
        return $this->success(new OrdersResource($order));

    }

    public function driver_waiting(Request $request)
    {
        $order = Orders::find($request->order_id);
        $order->update(['status' => 'waiting']);
        $user = User::find($order->user_id);
        $message = "سيصل سائقك بعد وقت قصير من وصوله، وسينتظر لمدة 5 دقائق قبل بدء تحصيل الرسوم، استمتع بالرحلة";
        $datapayload = array($user->id);
        $data = array(
            'title' => 'لديك رسالة جديدة',
            'sound' => "default",
            'data' => $datapayload,
            'body' => $message,
            'color' => "#79bc64"
        );

        $fields = array(
            'registration_ids' => $user->firebase_token,
            'notification' => $data,
            'data' => $datapayload,
            "priority" => "high",
        );
        $headers = array(
            'Authorization: key=AAAAR2GKiPM:APA91bEI2JzXop_BKhQJwhdXCJpKFk-M_bBo5DDS4JCDotkx_nlpbgLLsmjnUaJv0eVzjVGZlUrGB3WpUrCUbzrGKCiW47881QrlrIEcuB4ssxVqzUfYbEoDXzrcbq25GWjfbz1oLUXL',
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_exec($ch);
        curl_close($ch);
        UserNotification::create([
            'user_id' => $user->id,
            'title' => $data['title'],
            'body' => $data['body'],
            'image' => 'images/note.svg',
            'color' => '#0DA600',
        ]);
        Chat::create([
            'user_id' => $user->id,
            'driver_id' => \auth('driver')->user()->id,
            'driver_message' => $message,
            'order_id' => $request->order_id,
        ]);
        return $this->successMessage(__('messages.success'));


    }
    public function completed_trips()
    {
        $driver_id=\auth('driver')->user()->id;
        $order=Orders::where('driver_id',$driver_id)
            ->where('status','completed')->orderBy('id', 'desc')->get();
        return $this->success(CompletedTripsResource::collection($order));

        }


}
