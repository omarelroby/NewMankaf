<?php

namespace App\Http\Controllers\api\users;

use App\Http\Resources\CancelationResource;
use App\Http\Resources\CategoryResource;
use App\Http\Resources\ChatResource;
use App\Http\Resources\ChatResourceCollection;
use App\Http\Resources\CityResource;
use App\Http\Resources\CountryResource;
use App\Http\Resources\FaqsResource;
use App\Http\Resources\ModelsResource;
use App\Http\Resources\NotificationResource;
use App\Http\Resources\NotificationResourceCollection;
use App\Http\Resources\OrdersResource;
use App\Http\Resources\OrdersResourceCollection;
use App\Http\Resources\SlidersResource;
use App\Http\Resources\UserResource;
use App\Http\Resources\YearResource;
use App\Models\Cancelation;
use App\Models\Category;
use App\Models\Chat;
use App\Models\City;
use App\Models\Country;
use App\Models\Driver;
use App\Models\DriverRate;
use App\Models\Faqs;
use App\Models\Models;
use App\Models\Notification;
use App\Models\Orders;
use App\Models\Sliders;
use App\Models\User;
use App\Models\UserNotification;
use App\Models\UserRate;
use App\Models\WalletRequest;
use App\Models\Year;
use App\Traits\Response;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class UsersController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    use response;


    public function categories()
    {
        $categories = Category::all();
        return $this->successMessage(__('messages.categories-message'),CategoryResource::collection($categories));

    }
    public function sliders()
    {
        $sliders=Sliders::all();
        return $this->successMessage(__('messages.slider-message'),SlidersResource::collection($sliders));
    }
    public function add_wallet(Request $request)
    {
        $user_id=auth('api')->user()->id;
        $oValidatorRules =
            [
                'cash' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        WalletRequest::create([
            'cash'=>$request->cash,
            'user_id'=>$user_id,
        ]);
        $user=User::find($user_id);
        $user->update(['wallet'=>$user->wallet+$request->cash]);
        return $this->successMessage(__('dashboard.success'));
    }
    public function get_wallet()
    {
        $user_id=auth('api')->user()->id;
       $all_cash=WalletRequest::where('user_id',$user_id)->orderBy('id', 'desc')->get();
        $user=User::find($user_id);
        $data=[
            'transactions'=>$all_cash,
            'balance'=>$user->wallet
        ];
         return $this->success($data);
    }
    public function user_cancelation()
    {

        $user_id=\auth('api')->user()->id;
        $user=User::find($user_id);
        if ($user)
        {
            $reasons=Cancelation::where('type','customer')->get();
            return $this->success(CancelationResource::collection($reasons));
        }
        else
        {
            return $this->error(__('dashboard.user-not-found'));
        }
    }
    public function user_cancel_order(Request $request)
    {
        $user_id=\auth('api')->user()->id;
        $user=User::find($user_id);
        $order=Orders::where('user_id',$user_id)
            ->where('id',$request->order_id)->first();
        $driver=Driver::where('id',$order->driver_id)->first();
         if ($order)
        {
            $order->update([
                'status'=>'canceled',
                'reason_id'=>$request->reason_id,
                'comment'=>$request->comment,
                'cancelled_by'=>$user->name,
            ]);
            $datapayload=array('order_id'=>$order->id);
            $data = array(
                'title'=>'تم الغاء طلبك',
                'sound' => "default",
                'data'=>$datapayload,
                'body'=>"لسوء الحظ، اضطر سائقك إلى إلغاء الرحلة، يرجى طلب رحلة جديدة وسنقوم بنقلك قريبًا",
                'color' => "#79bc64"
            );

            $fields = array(
                'registration_ids'=>$driver->fcm_token,
                'notification'=>$data,
                'data'=>$datapayload,
                "priority" => "high",
            );
            $headers = array(
                'Authorization: key=AAAAR2GKiPM:APA91bEI2JzXop_BKhQJwhdXCJpKFk-M_bBo5DDS4JCDotkx_nlpbgLLsmjnUaJv0eVzjVGZlUrGB3WpUrCUbzrGKCiW47881QrlrIEcuB4ssxVqzUfYbEoDXzrcbq25GWjfbz1oLUXL',
                'Content-Type: application/json'
            );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            curl_exec($ch);
            curl_close( $ch );
            Notification::create([
                'driver_id'=>$driver->id,
                'title'=>$data['title'],
                'body'=>$data['body'],
                'image'=>'images/close.svg',
                'color'=>'#E30000',
            ]);
            return $this->successMessage(__('messages.success-update'));

        }
        else
        {
            return $this->error(__('messages.user-not-found'));
        }

    }
    public function get_user_orders()
    {

        $user_id=auth('api')->user()->id;
        $orders=Orders::where('user_id',$user_id)->orderBy('id', 'desc')->paginate(10);
        return $this->successMessage(__('messages.success-orders'),[ new OrdersResourceCollection($orders)]);

    }
    public function user_pay(Request $request)
    {
        $user_id=auth('api')->user()->id;
        $user=User::find($user_id);
        $order=Orders::where('user_id',$user_id)->
            where('id',$request->order_id)->first();
        if ($order)
        {
            if ($order->status=='finished'&&$order->paid==0)
            {
                if ($request->payment_method=='wallet')
                {
                    if($user->wallet>=$order->price)
                    {
                        $cash=$user->wallet-$order->price;
                        $user->update(['wallet'=>$cash]);
                        WalletRequest::create([
                                'order_id'=>$order->id,
                                'cash'=>$cash,
                                'user_id'=>$user_id,
                        ]);
                        $driver=Driver::find($order->driver_id);
                        $driver->update(['balance'=>$driver->balance+$order->driver_commision]);
                        WalletRequest::create([
                            'order_id'=>$order->id,
                            'cash'=>$order->driver_commision,
                            'driver_id'=>$driver->id,
                        ]);
                        $order->update(['payment_method'=>'wallet','paid'=>1]);
                        return $this->successMessage(__('messages.success-update'));

                    }
                    else
                    {
                        return $this->error(__('messages.error-not-enough-cash'));
                    }

                }
                else
                {
                    $order->update(['payment_method'=>'cash','paid'=>1]);
                    return $this->successMessage(__('messages.success-update'));

                }

            }
            else
            {
                return  $this->error(__('messages.error-not-finish'));
            }

        }
        else
        {
            return $this->error(__('messages.error-order'));
        }

    }
    public function user_notifications()
    {
        $user_id=auth('api')->user()->id;
        $notifications=UserNotification::where('user_id',$user_id)->orderBy('id', 'desc')->paginate(10);
        return $this->successMessage(__('messages.notification-message'),[new NotificationResourceCollection($notifications)]);
     }
    public function driver_comment(Request $request)
    {
        $user_id=auth('api')->user()->id;
        DriverRate::create(
            [
                'driver_id'=>$request->driver_id,
                'user_id'=>$user_id,
                'rate'=>$request->rate,
                'comment'=>$request->comment,
            ]
        );
        $driver=Driver::find($request->driver_id);
        $avg_rate=DriverRate::where('driver_id',$request->driver_id)->pluck('rate');
        $count=$avg_rate->count();
        $sum=DriverRate::where('driver_id',$request->driver_id)->sum('rate');
        $driver->update(['avg_rate'=>$sum/$count]);
        return $this->successMessage(__('dashboard.success'));

    }
    public function user_rate(Request $request)
    {
        $driver_id=auth('driver')->user()->id;
        $user=User::find($request->user_id);
        UserRate::create(
            [
                'driver_id'=>$driver_id,
                'user_id'=>$request->user_id,
                'rate'=>$request->rate,
                'comment'=>$request->comment,
            ]
        );
        $avg_rate=UserRate::where('user_id',$request->user_id)->pluck('rate');
        $count=$avg_rate->count();
        $sum=UserRate::where('user_id',$request->user_id)->sum('rate');
        $user->update(['avg_rate'=>$sum/$count]);

        return $this->successMessage(__('dashboard.success'));

    }
    public function get_user_faqs()
    {
        $driver_faqs=Faqs::where('type','user')->get();
        return $this->success(FaqsResource::collection($driver_faqs));

    }
    public function delete_user_notification(Request $request)
    {
        UserNotification::where('id',$request->notification_id)
            ->where('user_id',\auth('api')->user()->id)->delete();
        return $this->successMessage(__('dashboard.deleted'));

    }
    public function user_message(Request $request)
    {
        $user_id=auth('api')->user()->id;
        $oValidatorRules =
            [
                'driver_id' => 'required',
                'order_id' => 'required',
                'user_message' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails())
        {
            return $this->error($validator->errors()->first());
        }
        $driver=Driver::find($request->driver_id);
        $datapayload=array($user_id);
        $data = array(
            'title'=>'لديك رسالة جديدة',
            'sound' => "default",
            'data'=>$datapayload,
            'body'=>$request->user_message,
            'color' => "#79bc64"
        );

        $fields = array(
            'registration_ids'=>$driver->fcm_token,
            'notification'=>$data,
            'data'=>$datapayload,
            "priority" => "high",
        );
        $headers = array(
            'Authorization: key=AAAAR2GKiPM:APA91bEI2JzXop_BKhQJwhdXCJpKFk-M_bBo5DDS4JCDotkx_nlpbgLLsmjnUaJv0eVzjVGZlUrGB3WpUrCUbzrGKCiW47881QrlrIEcuB4ssxVqzUfYbEoDXzrcbq25GWjfbz1oLUXL',
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        curl_exec($ch);
        curl_close( $ch );
        UserNotification::create([
            'user_id'=>$user_id,
            'title'=>$data['title'],
            'body'=>$data['body'],
            'image'=>'images/note.svg',
            'color'=>'#0DA600',
        ]);
        Chat::create([
            'user_id' => $user_id,
            'order_id' => $request->order_id,
            'user_message' => $request->user_message,
            'driver_id' => $request->driver_id,
        ]);
        return $this->successMessage(__('messages.success'));

    }
    public function get_user_chat(Request $request)
    {
        $user_id=auth('api')->user()->id;
        $chat=Chat::where('order_id',$request->order_id)
            ->where('user_id',$user_id)->orderBy('id', 'desc')->paginate(10);
        return $this->success(new ChatResourceCollection($chat));

    }
    public function get_user_order(Request $request)
    {
        $order=Orders::where('id',$request->order_id)->where('user_id',auth('api')->user()->id)->first();
        return $this->success(new OrdersResource($order));
    }
    public function delete_order(Request $request)
    {
        $user_id=auth('api')->user()->id;
        $order=Orders::where('user_id',$user_id)
            ->where('id',$request->order_id)->first();
        if ($order)
        {
            $order->delete();
            return $this->successMessage(__('messages.delete'));
        }
        else
        {
            return $this->error('Sorry Order Not Found,Or Should The Order has this User ');
        }
    }






}
