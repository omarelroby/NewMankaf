<?php

namespace App\Http\Controllers\api;

use App\Events\OrderRequests;
use App\Events\OrderTracking;
use App\Http\Resources\CityResource;
use App\Http\Resources\CountryResource;
use App\Http\Resources\DriverResource;
use App\Http\Resources\ManufacuresResource;
use App\Http\Resources\ModelsResource;
use App\Http\Resources\OrdersResource;
use App\Http\Resources\SettingResource;
use App\Http\Resources\UserResource;
use App\Http\Resources\YearResource;
use App\Models\Captin;
use App\Models\City;
use App\Models\Country;
use App\Models\Driver;
use App\Models\DriverRequests;
use App\Models\Manufactur;
use App\Models\Models;
use App\Models\Notification;
use App\Models\Orders;
use App\Models\Setting;
use App\Models\User;
use App\Models\VehicleType;
use App\Models\Year;
use App\Traits\Response;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class HomeController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    use Response;

    public function index(){
        return view('dashboard.home');
    }
    public function countries()
    {
        $countries = Country::all();
        return $this->success(CountryResource::collection($countries));

    }

    public function user_register(Request $request)
    {
        $oValidatorRules =
            [
                'name' => 'required',
                'email' => 'required|unique:users,email',
                'phone' => 'required|unique:users,phone',
                'password' => 'required',
             ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $data = $request->all();
        if ($request->has('password')) {
            $data['password'] = bcrypt($request->password);
        }
        $code =rand ( 1000 , 9999 );
        User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'phone' => $data['phone'],
             'confirmation_code' => $code,
        ]);
        return $this->successMessage(__('messages.success'),['confirmation_code'=>$code]);
    }

    public function user_verify(Request $request)
    {
        $oValidatorRules =
            [
                'verification_code' => 'required',
                 'phone' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $user = User::where('phone', $request->phone)->first();
        if ($user) {
            if ($user->confirmation_code == $request->verification_code) {
                $user->update([
                    'verify' => 1,
                    'confirmation_code' => null,
                ]);
                return $this->successMessage(__('messages.activation'), [
                    'token' => 'Bearer' . ' ' . $user->createToken($user->name)->accessToken,'user'=>new UserResource($user)]);
            } else {
                return $this->error(__('messages.error-active'));
            }


        } else
        {
            return $this->error(__('messages.check'));
        }
    }
    public function user_verify_new(Request $request)
    {
        $oValidatorRules =
            [
                'verification_code' => 'required',
                 'phone' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $user = User::where('phone', $request->phone)->first();
        if ($user) {
            if ($user->confirmation_code == $request->verification_code) {
                $user->update([
                    'verify' => 1,
                    'confirmation_code' => null,
                    'password'=>$user->new_password,

                ]);
                $user->update(['new_password'=>null]);
                return $this->successMessage(__('messages.activation'), [
                    'token' => 'Bearer' . ' ' . $user->createToken($user->name)->accessToken,'user'=>new UserResource($user)]);
            } else {
                return $this->error(__('messages.error-active'));
            }


        } else
        {
            return $this->error(__('messages.check'));
        }
    }

    public function user_login(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
                'password' => 'required',
                'firebase_token' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $user = User::where('phone', $request->phone)->first();
        if ($user)
        {
            if ($user->verify == 1)
            {
                    if (Hash::check($request->password, $user->password)) {
                        $user->update(['firebase_token'=>$request->firebase_token]);
                        $data =
                            [
                                'user' => new UserResource($user),
                                'token' =>'Bearer'.' '.$user->createToken($user->name)->accessToken,
                            ];
                        return $this->successMessage(__('messages.success-login'),$data);
                    }
                    else
                    {
                        return $this->error(__('messages.password-wrong'));
                    }
            }
            else
            {
                return $this->error(__('messages.error-account'));
            }
        }
        else
        {
            return $this->error(__('messages.check'));
        }

    }
    public function forget_password(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
             ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $user=User::where('phone',$request->phone)->first();
        if($user)
        {
             $code =rand ( 1000 , 9999 );
             $user->update(['confirmation_code'=>$code]);
             return $this->successMessage(__('messages.send-code'),['confirmation_code'=>$code]);
        }
        else
        {
            return $this->error(__('messages.check'));
        }
    }
    public function forget_user_password_new(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
                'new_password' => 'required',
             ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $user=User::where('phone',$request->phone)->first();
        if($user)
        {
             $code =rand ( 1000 , 9999 );
             $user->update(['confirmation_code'=>$code,'new_password'=>bcrypt($request->new_password)]);
             return $this->successMessage(__('messages.send-code'),['confirmation_code'=>$code]);
        }
        else
        {
            return $this->error(__('messages.check'));
        }
    }
    public function reset_password(Request $request)
    {
        $oValidatorRules =
            [
                'phone' => 'required',
                'code' => 'required',
                'newPassword' => 'required',
            ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails())
        {
            return $this->error($validator->errors()->first());
        }
        $user=User::where('phone',$request->phone)->first();
        if ($user)
        {
            if ($user->confirmation_code==$request->code)
            {
                $user->update([
                    'password'=>bcrypt($request->newPassword),
                    'confirmation_code'=>null,
                    'verify'=>1
                ]);
                $data=[
                    'user'=>new UserResource($user),
                    'token'=>$user->createToken($user->name)->accessToken,
                ];
                return $this->successMessage(__('messages.changed-password'),$data);
            }
            else
            {
                return $this->error(__('messages.error-active'));
            }
        }
        else
        {
            return $this->error(__('messages.check'));

        }
    }
    public function cities($country_id)
    {
        $cities=City::where('country_id',$country_id)->get();
        return $this->success(CityResource::collection($cities));
    }
    public function all_years()
    {
        $years=Year::all();
        return $this->success(YearResource::collection($years));
    }
    public function models(Request $request)
    {
        $models=Models::where('manufactur_id',$request->manufactur_id)->get();
        return $this->success(ModelsResource::collection($models));

    }
    public function resend_otp(Request $request)
    {
        $user=User::where('phone',$request->phone)->first();
        if ($user)
        {
            $code =rand ( 1000 , 9999 );
            $user->update(['confirmation_code'=>$code]);
             return $this->successMessage(__('messages.send-code'),['confirmation_code'=>$code]);


        }
        else
        {
            return $this->error(__('messages.check'));
        }

    }
    public function setting()
    {
        $setting=Setting::first();
        return $this->success(new SettingResource($setting));
    }
    public function manufacturers(Request $request)
    {
         $manufactur=Manufactur::where('vehicle_type_id',$request->vehicle_type_id)->get();
         return $this->success(ManufacuresResource::collection($manufactur));

    }
    public function orders(Request $request)
    {
        $oValidatorRules = [
            'pick_up_longitude' => 'required',
            'pick_up_latitude' => 'required',
            'destination_longitude' => 'required',
            'destination_latitude' => 'required',
            'number_of_kilo' => 'required|integer',
            'time_in_minutes' => 'required|integer',
            'price' => 'required',
            'vehicle_type_id' => 'required|exists:vehicle_type,id',
        ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails()) {
            return $this->error($validator->errors()->first());
        }
        $user=auth('api')->user()->id;
        $commission=VehicleType::find($request->vehicle_type_id)->driver_commission;
        $order=Orders::create([
            'user_id'=>$user,
            'pick_up_longitude'=>$request->pick_up_longitude,
            'pick_up_latitude'=>$request->pick_up_latitude,
            'destination_longitude'=>$request->destination_longitude,
            'destination_latitude'=>$request->destination_latitude,
            'number_of_kilo'=>$request->number_of_kilo,
            'time_in_minutes'=>$request->time_in_minutes,
            'price'=>$request->price,
            'vehicle_type_id'=>$request->vehicle_type_id,
            'pickup_name'=>$request->pickup_name??null,
            'destination_name'=>$request->destination_name??null,
            'driver_commision'=>($commission/100)*$request->price,
        ]);

        $drivers=Captin::where('vehicle_type_id',$request->vehicle_type_id)->pluck('driver_id')->toArray();
        $allDrivers=Driver::whereIn('id',$drivers)->where('is_online',1)
            ->where('status','approved')->get();
        $DriversFcm=Driver::whereIn('id',$drivers)->where('is_online',1)
            ->where('status','approved')->pluck('fcm_token','id');
        foreach ($DriversFcm as $id=>$driver)
        {
            $datapayload= array('driver_id' => $id);
            $data = array(
                'title'=>'هناك طلب جديد',
                'sound' => "default",
                'data'=>$datapayload,
                'body'=>"هناك طلب جديد يرجي الموافقة للتنفيذ",
                'color' => "#79bc64"
            );

            $fields = array(
                'registration_ids'=>$driver,
                'notification'=>$data,
                'data'=>$datapayload,
                "priority" => "high",
            );
            $headers = array(
                'Authorization: key=AAAA3uSxKr0:APA91bG3_UiRC8jfVrbVAI9FJGXgdeXellR1H4KTmbMjPC62AS2KEPlPDsZcKSgvjVaGMiy1UNi3ZKKCU9rgATDftR6VNmUSfqFNktudqiJSBnTFHinEz46-TECqjcElK0vZwxg8xKJg',
                'Content-Type: application/json'
            );
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            curl_exec($ch);
            curl_close( $ch );

            Notification::create([
                'driver_id'=>$id,
                'title'=>$data['title'],
                'body'=>$data['body'],
                'image'=>'images/note.svg',
                'color'=>'#0DA600',

            ]);

        }
        foreach ($allDrivers as $driver)
        {
            DriverRequests::create([
                'driver_id'=>$driver->id,
                'order_id'=>$order->id,
            ]);
         }
        broadcast(new OrderRequests($order));
        return $this->successMessage(__('messages.success'),[new OrdersResource($order)]);
    }
    public function user_logout()
    {
        $user = auth('api')->user()->token();
        $user->revoke();
        return $this->successMessage(__('messages.success-logout'));
    }
    public function get_user()
    {
        $user_id=auth('api')->user()->id;
         $user=User::find($user_id);
        return $this->success(new UserResource($user));
    }
    public function update_user(Request $request)
    {
         $oValidatorRules = [
            'image' => 'nullable',
            'name' => 'required',

        ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails())
        {
            return $this->error($validator->errors()->first());
        }
        $data=$request->all();
        $user=User::find(\auth('api')->user()->id);
        if ($request->has('image'))
        {
            $path='public/profile';
            $ext=$request->file('image')->getClientOriginalExtension();
            $name=time().'.'.$ext;
            $data['image']=$request->file('image')->move($path,$name);
            $user->update(['image'=>$data['image']]);
        }
        $user->update(['name'=>$request->name]);
        return  $this->successMessage(__('dashboard.update'),[new UserResource($user)]);

    }
    public function update_password(Request $request)
    {
        $oValidatorRules = [
             'old_password' => 'required',
            'new_password' => 'required',

        ];
        $validator = Validator::make($request->all(), $oValidatorRules);
        if ($validator->fails())
        {
            return $this->error($validator->errors()->first());
        }
        $user=User::find(\auth('api')->user()->id);
        if( !Hash::check($request->old_password, $user->password))
        {
            return $this->error(__('dashboard.check-password'));
         }
        else
         {
             $user->update(['password'=>bcrypt($request->new_password)]);
             return  $this->successMessage(__('dashboard.updated-password'));
         }
    }


}
