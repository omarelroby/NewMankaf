<?php

namespace App\Http\Middleware;

use App\Traits\Response;

use Illuminate\Auth\Middleware\Authenticate as Middleware;

class Authenticate extends Middleware
{
    use Response;
    protected function redirectTo($request)
    {
        if( $request->is('api/*')){

            abort($this->error('Unauthenticated',[],401));
        }
        if (! $request->expectsJson()) {
            return route('login');
        }

    }
}
