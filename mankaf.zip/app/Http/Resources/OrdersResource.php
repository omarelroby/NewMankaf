<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class OrdersResource extends JsonResource
{
    public $order_status;

    public function toArray($request)
    {
        if($this->status=='pending')
        {
            $this->order_status=__('messages.pending');
        }
        elseif ($this->status=='canceled')
        {
            $this->order_status=__('messages.canceled');

        }
        elseif ($this->status=='completed')
        {
            $this->order_status=__('messages.completed');

        }
        elseif ($this->status=='accepted')
        {
            $this->order_status=__('messages.accepted');

        }
        elseif ($this->status=='started')
        {
            $this->order_status=__('messages.started');

        }


        return [
            'id'=>$this->id,
            'pick_up_longitude'=>$this->pick_up_longitude,
            'pick_up_latitude'=>$this->pick_up_latitude,
            'destination_longitude'=>$this->destination_longitude,
            'destination_latitude'=>$this->destination_latitude,
            'number_of_kilo'=>$this->number_of_kilo,
            'time_in_minutes'=>$this->time_in_minutes,
            'price'=>$this->price,
            'code'=>$this->code,
            'status'=>$this->order_status,
            'comment'=>$this->comment,
            'cancelled_by'=>$this->cancelled_by,
            'pickup_name'=>$this->pickup_name,
            'destination_name'=>$this->destination_name,
            'driver_commision'=>$this->driver_commision,
            'payment_method'=>$this->payment_method,
            'created_at'=>date('d M Y',strtotime($this->created_at)),
            'vehicle_type'=>new VehiclesTypeResource($this->vehicles),
            'user'=>new UserResource($this->user),
            'driver'=>new DriverResource($this->driver),



        ];
    }
}
