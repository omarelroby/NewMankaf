<?php

namespace App\Http\Resources;

use App\Models\Orders;
use Illuminate\Http\Resources\Json\JsonResource;

class DriverResource extends JsonResource
{

    public function toArray($request)
    {
        $time = Orders::where('driver_id', $this->id)->sum('time_in_minutes');
        $kilos = Orders::where('driver_id', $this->id)->sum('number_of_kilo');
        $orders = Orders::where('driver_id', $this->id)->get();
        $timebyhour=($time/60)>=1?intval($time/60):0;
        $minutes=$time%60;



        return [
            'id'=>$this->id,
            'name' => $this->name,
            'email' => $this->email,
            'image' =>asset($this->image??'images/user.jpg') ,
            'country'=>new CountryResource($this->country),
            'phone'=>$this->phone,
            'status'=>($this->status=='pending')?__('messages.pending'):__('messages.approved'),
            'longitude'=>$this->longitude,
            'latitude'=>$this->latitude,
            'avg_rate'=>$this->avg_rate,
            'is_online'=>$this->is_online?true:false,
            'captin'=>new CaptinInfoResource($this->captin),
            'document'=>new DriverDocumentResource($this->document),
            'registered'=>$this->registered,
            'completed'=>$this->captin&&$this->document?true:false,
            'total_time_online' => $timebyhour.'h'.$minutes.'m',
            'total_trips' => $orders->count(),
            'total_distance' => $kilos,

        ];
    }
}
