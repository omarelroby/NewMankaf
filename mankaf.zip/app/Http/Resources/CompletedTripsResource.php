<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CompletedTripsResource extends JsonResource
{
    public $order_status;

    public function toArray($request)
    {


        $timebyhour=($this->time_in_minutes/60)>=1?intval($this->time_in_minutes/60):0;
        $minutes=$this->time_in_minutes%60;
        return [
            'id'=>$this->id,
            'Distance'=>$this->number_of_kilo,
            'Duration'=>$timebyhour.'h'.$minutes.'m',
            'Earned'=>$this->driver_commision,




        ];
    }
}
