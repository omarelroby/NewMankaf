<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class DriverOrdersHistoryResource extends JsonResource
{

    public function toArray($request)
    {
        return [
            'number_of_kilo'=>$this->number_of_kilo??'0',
            'time_in_minutes'=>$this->time_in_minutes??'0',




        ];
    }
}
