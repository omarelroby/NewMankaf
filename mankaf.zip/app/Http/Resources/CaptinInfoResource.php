<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CaptinInfoResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,

            'identity_expiry'=>$this->identity_expiry,
            'passport_number'=>$this->passport_number,
            'address'=>$this->address,
            'city_id'=>$this->city_id,
            'country_id'=>$this->country_id,
            'vehicle_number'=>$this->vehicle_number,
            'vehicle_expiry'=>$this->vehicle_expiry,
            'vehicle_owner_name'=>$this->vehicle_owner_name,
            'model_id'=>$this->model_id,
            'year_id'=>$this->year_id,
             'vehicle_type_id'=>$this->vehicle_type_id,
            'make_id'=>$this->make_id,
            'passport_expiry'=>$this->passport_expiry,


        ];
    }
}
