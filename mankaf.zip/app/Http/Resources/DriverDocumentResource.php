<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class DriverDocumentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'front_id_uploaded' => $this->front_id_uploaded,
            'back_id_uploaded' => $this->back_id_uploaded,
            'driving_license_card_front' => $this->driving_license_card_front,
            'driving_license_card_back' => $this->driving_license_card_back,
            'vehicle_book_front' => $this->vehicle_book_front,
            'vehicle_book_back' => $this->vehicle_book_back,



        ];
    }
}
